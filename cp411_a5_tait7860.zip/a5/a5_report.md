# A5 Report

Author: Janelle Tait

Date: 2021-11-15

Check [readme.txt](readme.txt) for lab work statement and self-evaluation. 

## Q1 Curve and surface computing (short_answer)
	
### Q1.1 Cubic spline computing

![image caption](images/1.1part1.jpg){width=90%}


![image caption](images/1.1part2.jpg){width=90%}

### Q1.2 Rotation surface and normal


![image caption](images/1.2.jpg){width=90%}


## Q2 Curve, surface, texture, GLSL (lab practice)
	
### Q2.1 Curve model and rendering
 
Complete? (Yes) 

If Yes, insert a screen shot image to show the completion.

![image caption](images/2.1.png){width=90%}


### Q2.2 Surface model and rendering
 
Complete? (Yes) 

If Yes, insert a screen shot image to show the completion.

![image caption](images/2.2.png){width=90%}


### Q2.3 Texture mapping
 
Complete? (Yes) 

If Yes, insert a screen shot image to show the completion.

![image caption](images/2.3.png){width=90%}


### Q2.4 GPU programming by GLSL
 
Complete? (Yes) 

If Yes, insert a screen shot image to show the completion.

![image caption](images/2.4.1.png){width=90%}

![image caption](images/2.4.2.png){width=90%}



## Q3 SimpleView3 - texture, GLSL, curve, and surface (programming)
	
### Q3.1 Texture mapping basics
 

Complete? (Yes) 

![image caption](images/3.1.png){width=90%}



### Q3.2 Solar system with texture mapping
 
Complete? (Yes) 

![image caption](images/3.2.png){width=90%}



### Q3.3 Bezier curve
 

Complete? (Yes) 

![image caption](images/3.3.png){width=90%}



### Q3.4 Rotation surface of Bezier curve
 

Complete? (Yes) 

![image caption](images/3.4.png){width=90%}


### Q3.5 Phong shading by GLSL
 
Complete? (Yes) 

![image caption](images/3.5.png){width=90%}





**References**

1. CP411 a5
2. Add your references if you used. 
