# A2 Report

Author: Janelle Tait

Date: 2021-10-07

Check [readme.txt](readme.txt) for lab work statement and self-evaluation. 

## Q1 Graphics pipeline (short answer)
	
### Q1.1 Primitives

Graphics primitives are the most basic units that are used to construct more complex images. The graphics primitives include points, line segments, triangles, and polygons. Objects are made by combining several primitives; any object can be broken down into a set of primitives.The graphics 
pipeline transforms primitives into models and then models into scenes.

### Q1.2 Coordinate systems & transformations

The coordinate systems in the pipeline are the Modeling Coordinate System, World Coordinate System, Viewer Coordinate System, Normalized Device Coordinate System, and Device/Screen Coordinate System. Transformations in the pipeline include modeling transforms (translate, rotation, etc.), viewing transforms
(position of camera), projection transforms (project objects onto view plane), and display transformation (mapping view to display).

### Q1.3 Scan conversion

A scan conversion algorithm is an algorithm that paints pixels whose centers are inside a polygon or along a line segment to be rendered.

![q1 image1](images\q1 image1.png){width=90%}

![q1 image2](images\q1 image2.png){width=90%}

![q1 image3](images\q1 image3.png){width=90%}


## Q2 OpenGL and Glut (lab practice)
	
### Q2.1 OpenGL primitives
 
Complete? (Yes) 

![q2-1 image](images/q2-1 image.png){width=90%}


### Q2.2 Interactive graphics
 
Complete? (Yes) 

![q2-2 image](images/q2-2 image.png){width=90%}


### Q2.3 Bitmap file I/O
 
Complete? (Yes) 

![q2-3 image](images/q2-3 image.png){width=90%}



## Q3 SimpleDraw (programming)
	
### Q3.1 Display window and menu
 

Complete? (Yes) 


![q3-1 image](images/q3-1 image.png){width=90%}


### Q3.2 Data structures
 

Complete? (Yes) 

![q3-2 image](images/q3-2 image.png){width=90%}



### Q3.3 Draw rectangles
 

Complete? (Yes) 

![q3-3 image](images/q3-3 image.png){width=90%}



### Q3.4 Draw circles
 

Complete? (Yes) 

![q3-4 image](images/q3-4 image.png){width=90%}


### Q3.5 Edit features

Complete? (Yes) 

![q3-5 image](images/q3-5 image.png){width=90%}


### Q3.6 Save/Open SVG files

Complete? (Yes).  <br>If Yes, ![output.bmp](images/output.svg).

### Q3.7 Export to bitmap

Complete? (Yes).  <br>If Yes, ![ouput.bmp](images/output.bmp).

### Q3.8 Circle&Square artwork

Complete? (Yes).  <br>If Yes, ![C&S artwork in SVG](images/c&s.svg), ![C&S artwork in bitmap](images/c&s.bmp).




**References**

1. CP411 a2
2. Add your references if you used. 
