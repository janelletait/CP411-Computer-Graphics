# A3 Report

Author: Janelle Tait

Date: 2021-10-24

Check [readme.txt](readme.txt) for lab work statement and self-evaluation. 

## Q1 Graphics transformations (short_answer)
	
### Q1.1 Principle of transformations

1. The basic transformations are translation, rotation, and scaling. A composite transformation 
consists of a sequence of basic transformations.

2. The transformation formulas for both vectors and vertices are unified in 
homogeneous coordinates. As a result, translation, rotation, and scaling 
can be represented by matrix. Such generalization enhances simplicity, 
and thus the reliability of a graphics system. 

### Q1.2 Hand on 2D transformations
![first page](images/a3q2part1.jpg){width=90%}

![second page](images/a3q2part2.jpg){width=90%}

## Q2 Graphics transformation programming (lab practice)
	
### Q2.1 Warm up C++
 
Complete? (Yes) 

If Yes, insert a screen shot image to show the completion.

![image caption](images/a2part1.png){width=90%}


### Q2.2 2D transformations
 
Complete? (Yes) 

If Yes, insert a screen shot image to show the completion.

![image caption](images/q2part2.png){width=90%}


### Q2.3 3D object and transformations
 
Complete? (Yes) 

If Yes, insert a screen shot image to show the completion.

![image caption](images/q2part3.png){width=90%}


### Q2.4 Mesh object model
 
Complete? (Yes) 

If Yes, insert a screen shot image to show the completion.

![image caption](images/q2part4.png){width=90%}



## Q3 SimpleView - transformations (programming)
	
### Q3.1 Create and render cube objects
 

Complete? (Yes) 

If Yes, insert a screen shot image to show the completion.

![image caption](images/q3part1.png){width=90%}



### Q3.2 Create and render the pyramid object
 

Complete? (Yes) 

If Yes, insert a screen shot image to show the completion.

![image caption](images/q3part1.png){width=90%}



### Q3.3 Create and render the house object
 

Complete? (Yes) 

If Yes, insert a screen shot image to show the completion.

![image caption](images/q3part1.png){width=90%}



### Q3.4 MCS transforms
 

Complete? (Yes) 

If Yes, insert a screen shot image to show the completion.

![image caption](images/mcs_transform.png){width=90%}



### Q3.5 WCS transforms
 

Complete? (Yes) 

If Yes, insert a screen shot image to show the completion.

![image caption](images/wcs_transform.png){width=90%}



### Q3.6 VCS transforms
 
Complete? (Yes) 

If Yes, insert a screen shot image to show the completion.

![image caption](images/vcs_transform.png){width=90%}



**References**

1. CP411 a3
2. Add your references if you used. 
