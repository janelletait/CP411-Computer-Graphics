Name: Janelle Tait
ID: 180447860
Email: tait7860@mylaurier.ca
WorkID: cp411-a3
Statement: I claim that the enclosed submission is my individual work.

Fill in the self-evaluation in the following evaluation grid.
Symbols: Q -- Question, T -- Lab tasks
Field format: [self-evaluation/total marks/marker's evaluation]

For example, you put your self-evaluation, say 2, like [2/2/*]. 
If marker gives different evaluation value say 1, it will show 
[2/2/1] in the marking report. 

Evaluation grid: [self-evaluation/total/marker-evaluation]

A3

Q1 Graphics transformations

Q1.1 Principle of transformations         [5/5/*]
Q1.2 Hand on 2D transformations           [5/5/*]

Q2 Graphics transformation programming

Q2.1 Warm up C++                          [5/5/*]
Q2.2 2D transformations                   [5/5/*]
Q2.3 3D object and transformations        [5/5/*]
Q2.4 Mesh object model                    [5/5/*]

Q3 SimpleView - transformations

Q3.1 Create and render cube objects       [10/10/*]
Q3.2 Create and render the pyramid object [10/10/*]
Q3.3 Create and render the house object   [5/5/*]
Q3.4 MCS transforms                       [15/15/*]
Q3.5 WCS transforms                       [15/15/*]
Q3.6 VCS transforms                       [15/15/*]

Total:                                    [100/100/*]
