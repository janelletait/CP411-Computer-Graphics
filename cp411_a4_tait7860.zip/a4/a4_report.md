# A4 Report

Author: Janelle Tait

Date: October 31, 2021

Check [readme.txt](readme.txt) for lab work statement and self-evaluation. 

## Q1 Culling, Lighting, Shading (short_answer)
	
### Q1.1 Concepts of culling
1. Culling is a process of removing objects which are in the view volume but not visible.
Clipping is the process by which the polygons (or parts of polygons) that extend past view volume are removed.

2. Object precision hidden surface removal algorithms compute at the primitive level, namely determine if a primitive is visible.
Image precision hidden surface removal algorithms compute at pixel level, namely determine if a pixel is visible.

### Q1.2 Culling computing

![image caption](images/a4q1.1part1.jpg){width=90%}

![image caption](images/a4q1.1part2.jpg){width=90%}

### Q1.3 Concepts of lighting and shading
1. The 4 light models are: ambient light, point light, directional light, and material emission light.
2. A light model determines how reflection light shade is calculated and the color of every pixel or the amount of light reflected for different surfaces in the scene.
3. A shading model determines how a pixel shade and colour is calculated. Three shading models are constant shading, Gouraud shading, and Phong shading.
4. Gouraud shading interpolates the colours of vertices.

### Q1.4 Lighting computing

![image caption](images/1.4part1.jpg){width=90%}

![image caption](images/1.4part2.jpg){width=90%}


## Q2 OpenGL culling, lighting, shading (lab practice)
	
### Q2.1 Hidden surface removal
 
Complete? (Yes) 

![image caption](images/q2.1part1.png){width=90%}

![image caption](images/q2.1part2.png){width=90%}


### Q2.2 Lighting and Shading
 
Complete? (Yes) 

![image caption](images/q2.2part1.png){width=90%}


![image caption](images/q2.2part2.png){width=90%}


![image caption](images/q2.2part3.png){width=90%}


![image caption](images/q2.2part4.png){width=90%}


## Q3 SimpleView2 - culling, lighting, shading (programming)
	
### Q3.1 Culling
 

Complete? (Yes) 

![image caption](images/q3.1.png){width=90%}



### Q3.2 Lighting
 

Complete? (Yes) 

![image caption](images/q3.2.png){width=90%}



### Q3.3 Shading
 

Complete? (Yes) 

![image caption](images/q3.3.png){width=90%}



### Q3.4 Animations
 

Complete? (Yes) 

![image caption](images/q3.4.png){width=90%}




**References**

1. CP411 a4
2. Add your references if you used. 
