# A1 Report

Author: Janelle Tait

Date: 2021-09-18

Check [readme.txt](readme.txt) for lab work statement and self-evaluation. 

## Q1 Concepts of raster graphics (short answer)
	
### Q1.1 frame buffer

A frame buffer is a portion of memory containing data which represents all pixels in a video frame.

### Q1.2 pixel

A pixel is the smallest unit of a digital graphic. Pixels form a complete image when combined.

### Q1.3 color depth

Colour depth is the maximum number of colours that can be displayed by each pixel.

### Q1.4 resolution

Resolution is the number of pixels in a display.



## Q2 Concepts of raster display (short answer)
	
### Q2.1 scan line

A scan line is a row of pixels in a raster graphics image.

### Q2.2 refreshment & refresh rate

A frame must be refreshed in order to display a new image. The refresh rate is how many times per second the display can refresh and draw a new image.

### Q2.3 frame

A frame is an individual picture in a video or animation.



## Q3 Roles of CPU and GPU in CG (short answer)
	
### Q3.1 CPU roles

The CPU does model computing and sends graphic object model data to video memory and instructions to GPU.

### Q3.2 GPU roles

The GPU processes object data, rasterizes and stores the pixel data in the frame buffer.



## Q4 C/C++ OpenGL programming environment (lab practice)
	
### Q4.1 C/C++ OpenGL installation
 
Complete? (Yes) 

If Yes, insert a screen shot image to show the completion.

![cube](images\cube.png){width=90%}

![teapot](images\teapot.png){width=90%}

### Q4.2 OpenGL C project
 
Complete? (Yes) 

![image caption](images/blender.png){width=90%}

### Q4.3 OpenGL C++ project
 
Complete? (Yes) 

![image caption](images/glut-test.png){width=90%}


**References**

1. CP411 a1
2. Add your references if you used. 
